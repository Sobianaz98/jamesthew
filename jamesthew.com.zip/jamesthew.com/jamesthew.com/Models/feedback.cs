﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace jamesthew.com.Models
{
    public class feedback
    {
        [Key]
        public int userid { get; set; }

        [Required]
        public string username { get; set; }

        [Required]
        public string useremail { get; set; }

        [Required]
        public string subject { get; set; }

        [Required]
        public string message { get; set; }
        
    }
    }
