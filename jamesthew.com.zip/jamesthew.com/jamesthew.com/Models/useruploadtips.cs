﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace jamesthew.com.Models
{
    public class useruploadtips
    {
        [Key]
        public int userid { get; set; }

        [Required]
        public string subject { get; set; }

        [Required]
        public string message { get; set; }
        [DefaultValue(0)]
        public int status { get; set; }
    }
}
