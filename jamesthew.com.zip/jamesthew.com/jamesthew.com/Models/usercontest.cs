﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace jamesthew.com.Models
{
    public class usercontest
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Question { get; set; }
        [Required]
        public string CorrectAnswer { get; set; }
        [Required]
        [DefaultValue(0)]
        public int status { get; set; }
    }
}
