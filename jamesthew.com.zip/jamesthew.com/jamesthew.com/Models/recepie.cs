﻿using System.ComponentModel.DataAnnotations;

namespace jamesthew.com.Models
{
    public class recepie
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string RecipeName { get; set; }
        [Required]
        public string RecipeDescription { get; set; }

        [Required]
        public string RecipeType { get; set; }
        [Required]
        public string Image { get; set; }

    }
}
