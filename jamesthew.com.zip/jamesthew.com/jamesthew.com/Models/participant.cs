﻿using System.ComponentModel.DataAnnotations;

namespace jamesthew.com.Models
{
    public class participant
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Answer { get; set; }

    }
}
