﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace jamesthew.com.Models
{
    public class useruploadrecepie
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string RecipeName { get; set; }
        [Required]
        public string RecipeDescription { get; set; }
        [Required]
        public string Image { get; set; }
        [Required]
        [DefaultValue(0)]
        public int status { get; set; }


    }
}
