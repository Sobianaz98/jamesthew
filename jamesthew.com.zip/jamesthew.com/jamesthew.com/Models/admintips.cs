﻿using System.ComponentModel.DataAnnotations;

namespace jamesthew.com.Models
{
    public class admintips
    {
        [Key]
        public int userid { get; set; }

        [Required]
        public string subject { get; set; }

        [Required]
        public string message { get; set; }
    }
}
