﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace jamesthew.com.Models
{
    public class contest
    {
        [Key]
        public int userid { get; set; }

        [Required]
        public string contest_name { get; set; }

        [Required]
        public string contest_desc { get; set; }
        
        [Required]
        public string contest_prize { get; set; }

        [Required]
        public string contest_winner { get; set; }
    }
}
