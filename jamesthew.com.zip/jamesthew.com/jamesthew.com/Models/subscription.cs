﻿using System.ComponentModel.DataAnnotations;

namespace jamesthew.com.Models
{
    public class subscription
    {
        [Key]
        public int userid { get; set; }

        [Required]
        public string subscribername { get; set; }

        [Required]
        public string subscriberemail { get; set; }

        [Required]
        public int subscribercontact { get; set; }

        [Required]
        public string subscriberaddress { get; set; }

        [Required]
        public int cardnumber { get; set; }

        [Required]
        public int type { get; set; }
    }
}
