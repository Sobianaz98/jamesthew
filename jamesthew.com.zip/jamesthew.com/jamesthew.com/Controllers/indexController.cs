﻿using jamesthew.com.context;
using jamesthew.com.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.CodeAnalysis.Scripting;

namespace jamesthew.com.Controllers
{
    public class indexController : Controller
   
        {
            Sqlcontext sc;
            IWebHostEnvironment env;
            public indexController(Sqlcontext sc1, IWebHostEnvironment env)
            {
                this.sc = sc1;
                this.env = env;
            }


            public IActionResult Index()
        {
            
                return View();
            
        }
        public IActionResult tips()
        {
            var credentials = HttpContext.Session.GetString("usersession");

            if (credentials == null)
            {
                return View("login");
            }
            else
            {
                var viewModel = new TipsViewModel
                {
                    AdminTips = sc.tbladmintips.ToList(),
                    SecondTableData = sc.useruploadtips.Where(a => a.status == 1).ToList()
                    // Add more data as needed
                };
                ViewBag.username = HttpContext.Session.GetString("usersession");
                return View(viewModel);
            }
        }
        public IActionResult annouce()
        {
            var credentials = HttpContext.Session.GetString("usersession");

            if (credentials == null)
            {
                return View("login");
            }
            else
            {
                ViewBag.username = HttpContext.Session.GetString("usersession");

                return View(sc.announcements.ToList());
            }
        }
        public IActionResult fetchcontest()
        {
            var credentials = HttpContext.Session.GetString("usersession");
            ViewBag.username = HttpContext.Session.GetString("usersession");


            if (credentials == null)
            {
                return View("login");
            }
            else
            {
                return View(sc.contest.ToList());
            }
        }
        public IActionResult feedback()
        {
            var credentials = HttpContext.Session.GetString("usersession");

            if (credentials == null)
            {
                return View("login");
            }
            else
            {
                ViewBag.username = HttpContext.Session.GetString("usersession");

                return View();
            }
        }
        [HttpPost]
        public IActionResult feedback(feedback adc)
        {
            sc.feedback.Add(adc);
            sc.SaveChanges();
            ModelState.Clear();
            return View();
        }

        public IActionResult faqs()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(usermodel reg)
        {


            sc.tblregister.Add(reg);
            sc.SaveChanges();
            ModelState.Clear();
            ViewBag.result = " Congratulation!! your account has been succesfully created!";
            return View();
        }
        public IActionResult subscription()
        {
            var credentials = HttpContext.Session.GetString("usersession");

            if (credentials == null)
            {
                return View("login");
            }
            else
            {
                ViewBag.username = HttpContext.Session.GetString("usersession");

                return View();
            }
        }
        [HttpPost]
        public IActionResult subscription(subscription reg)
        {
            bool isSubscribed = ValidateSubscription(reg);

            // Set IsSubscribed in session
            HttpContext.Session.Set("IsSubscribed", BitConverter.GetBytes(isSubscribed));

            // Set the user session
            HttpContext.Session.SetString("usersession", reg.subscriberemail);

            ViewBag.username = HttpContext.Session.GetString("usersession");

            // Redirect based on subscription status
            if (isSubscribed)
            {
                return RedirectToAction("Index");  // Redirect to the appropriate page after successful subscription
            }
            else
            {
                return View("Subscription"); // Stay on the subscription form if the subscription is not successful
            }
            sc.subscription.Add(reg);
            sc.SaveChanges();
            ModelState.Clear();
            ViewBag.result = " Congratulation!! Your Account Has Been Subscribed To Premium Facilities!";
            return View();
        }

        private bool ValidateSubscription(subscription reg)
        {
            if(reg != null && !string.IsNullOrWhiteSpace(reg.subscriberemail) && reg.subscriberemail.EndsWith("") /* other conditions */)
    {
                // Valid subscription
                return true;
            }
    else
            {
                // Invalid subscription
                return false;
            }
        }

        public IActionResult updprofile(int id)
        {
            return View(sc.tblregister.Find(id));
        }
        [HttpPost]
        public IActionResult updprofile(usermodel cm)
        {
            var a = sc.tblregister.Find(cm.id);
            if (a != null)
            {
                a.name = cm.name;
                a.email = cm.email;
                a.password = cm.password;
                sc.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult login(usermodel user)
        {
            var credentials = sc.tblregister.Where(userinput => userinput.email == user.email && userinput.password == user.password).FirstOrDefault();
            if (credentials != null)
            {
                HttpContext.Session.SetString("usersession", credentials.name);
                ViewBag.username = HttpContext.Session.GetString("usersession");


                if (credentials.role == 0)
                {
                    return View("index");
                }
                else
                {
                    return View("../Admin/Index");
                }
            }
            ViewBag.error = "Credentials did not matched";
            return View();
        }
        public IActionResult Logout()
        {
            if (HttpContext.Session.GetString("usersession") != null)
            {
                HttpContext.Session.Remove("usersession");
            }
            return View("login");
        }
        public IActionResult getfreerecipes()
        {
            var freeRecipes = sc.tblrecepie.Where(x => x.RecipeType == "Free").ToList();
            var userRecipes = (sc.tbluserrecepie.Where(x => x.status == 1).ToList());

            var viewModel = new RecipeViewMod
            {
                FreeRecipes = freeRecipes,
                UserRecipes = userRecipes
            };

            return View(viewModel);
        }

        public IActionResult getpremiumrecipes()
        {
            bool isSubscribed = false;

            if (HttpContext.Session.TryGetValue("IsSubscribed", out byte[] isSubscribedBytes))
            {
                isSubscribed = BitConverter.ToBoolean(isSubscribedBytes, 0);
            }

            // If user is not subscribed, redirect to subscription form
            if (!isSubscribed)
            {
                return RedirectToAction("Subscription"); // Replace "SubscriptionForm" with the actual action/method for your subscription form
            }

            // If user is subscribed, show premium recipes
            return View(sc.tblrecepie.Where(x => x.RecipeType == "Premium").ToList());

            //return View(sc.tblrecepie.Where(x => x.RecipeType == "Premium").ToList());
        }


        public IActionResult search(string input)
        {
            if (input != null)
            {
                var matchingRecipes = sc.tblrecepie
                    .Where(x => x.RecipeName == input && x.RecipeType == "free") .ToList();
                if (matchingRecipes.Any())
                {
                    return View(matchingRecipes);
                }

                else
                {
                    ViewBag.Message = "No Recipes found";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        public IActionResult searchpremium(string inputsearch)
        {
            if (inputsearch != null)
            {
                var matchingRecipes = sc.tblrecepie
                    .Where(x => x.RecipeName == inputsearch && x.RecipeType == "premium")
                    .ToList();

                if (matchingRecipes.Any())
                {
                    return View(matchingRecipes);
                }
                else
                {
                    ViewBag.rec = "No Recipes found";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        public IActionResult useruploadrecepie()
        {
            var credentials = HttpContext.Session.GetString("usersession");

            if (credentials == null)
            {
                return View("login");
            }
            else
            {

                ViewBag.username = HttpContext.Session.GetString("usersession");

                return View();
            }


        }
        [HttpPost]
        public IActionResult useruploadrecepie(_useruploadrecepie rc)
        {

            String filename = "";

            String uploadFolder = Path.Combine(env.WebRootPath, "Gallery");
            filename = Guid.NewGuid().ToString() + "_" + rc.Photo.FileName;
            String mergevalue = Path.Combine(uploadFolder, filename);
            rc.Photo.CopyTo(new FileStream(mergevalue, FileMode.Create));


            useruploadrecepie data = new useruploadrecepie()
            {
                Image = filename,
                RecipeName = rc.RecipeName,
                RecipeDescription = rc.RecipeDescription
            };
            sc.tbluserrecepie.Add(data);
            sc.SaveChanges();
            ModelState.Clear();
            return View();
        }
        public IActionResult useruploadtips()
        {
            return View();

        }

        [HttpPost]
        public IActionResult useruploadtips(useruploadtips utp)
        {
            sc.useruploadtips.Add(utp);
            sc.SaveChanges();
            ModelState.Clear();
            return View();

        }

        










    }

}
