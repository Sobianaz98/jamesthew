﻿using jamesthew.com.Models;

namespace jamesthew.com.Controllers
{
    internal class RecipeViewMod
    {
        public List<recepie> FreeRecipes { get; set; }
        public List<useruploadrecepie> UserRecipes { get; set; }
    }
}