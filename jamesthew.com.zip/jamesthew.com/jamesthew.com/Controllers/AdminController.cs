﻿using jamesthew.com.context;
using jamesthew.com.Models;
using Microsoft.AspNetCore.Mvc;


namespace jamesthew.com.Controllers
{
    public class AdminController : Controller
    {
        Sqlcontext sc;
        IWebHostEnvironment env;
        public AdminController(Sqlcontext sc1, IWebHostEnvironment env)
        {
            this.sc = sc1;
            this.env = env;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Admintips()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Admintips(admintips ins)
        {
            sc.tbladmintips.Add(ins);
            sc.SaveChanges();
            ModelState.Clear();
            return View();
        }
        public IActionResult fetchfeedback()
        {
            return View(sc.feedback.ToList());
        }
        public IActionResult fetchusers()
        {
            return View(sc.tblregister.ToList());
        }
        public IActionResult fetchsubscribers()
        {
            return View(sc.subscription.ToList());
        }
        public IActionResult Announce()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Announce(announcements anc)
        {
            sc.announcements.Add(anc);
            sc.SaveChanges();
            ModelState.Clear();
            return View();

        }
        public IActionResult contest()
        {
            return View();
        }
        [HttpPost]
        public IActionResult contest(contest anc)
        {
            sc.contest.Add(anc);
            sc.SaveChanges();
            ModelState.Clear();
            return View();

        }
        public IActionResult uploadrecepie()
        {
            return View();
        }
        [HttpPost]
        public IActionResult uploadrecepie(_recepie recp)
        {
            String filename = "";

            String uploadFolder = Path.Combine(env.WebRootPath, "Gallery");
            filename = Guid.NewGuid().ToString() + "_" + recp.Photo.FileName;
            String mergevalue = Path.Combine(uploadFolder, filename);
            recp.Photo.CopyTo(new FileStream(mergevalue, FileMode.Create));


            recepie data = new recepie()
            {
                Image = filename,
                RecipeName = recp.RecipeName,
                RecipeDescription = recp.RecipeDescription,
                RecipeType = recp.RecipeType
            };
            sc.tblrecepie.Add(data);
            sc.SaveChanges();
            ModelState.Clear();
            return View();

        }
        public IActionResult Logout()
        {
            if (HttpContext.Session.GetString("usersession") != null)
            {
                HttpContext.Session.Remove("usersession");
            }
            return View("login");
        }
        public IActionResult useruploadrecepie()
        {
            return View(sc.tbluserrecepie.Where(x => x.status == 0).ToList());
        }
        public IActionResult Status(int Id)
        {
            var record = sc.tbluserrecepie.Find(Id);
            if (record != null)
            {
                record.status = 1;
                sc.SaveChanges();
               
            }
            return RedirectToAction("useruploadrecepie");
        } 
        public IActionResult approvedrecepie()
        {
            return View(sc.tbluserrecepie.Where(x => x.status == 1).ToList());

        }

        //public IActionResult approvedrecepie()
        //{
        //    return View(sc.tbluserrecepie.Where(x => x.status == 1).ToList());

        //}
        public IActionResult usertips()
        {
            return View(sc.useruploadtips.Where(b => b.status == 0).ToList());
        }
        public IActionResult userapprovetips(int id)
        {
            var tips = sc.useruploadtips.Find(id);

            if (tips != null)
            {
                tips.status = 1;
                sc.SaveChanges();

            }
            return RedirectToAction("usertips");
        }
        public IActionResult approvetips()
        {
            return View(sc.useruploadtips.Where(b => b.status == 1).ToList());
        }
        public IActionResult usercontest()
        {
            return View();
        }
        [HttpPost]

        public IActionResult usercontest(usercontest us)
        {
            sc.usercontest.Add(us);
            sc.SaveChanges();
            ModelState.Clear();
            return View();
        }


    }

    }

