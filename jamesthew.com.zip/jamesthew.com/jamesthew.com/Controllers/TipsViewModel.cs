﻿using jamesthew.com.Models;

namespace jamesthew.com.Controllers
{
    internal class TipsViewModel
    {
        public List<admintips> AdminTips { get; set; }
        public List<useruploadtips> SecondTableData { get; set; }
    }
}