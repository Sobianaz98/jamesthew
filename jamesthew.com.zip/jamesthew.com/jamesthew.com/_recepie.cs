﻿using System.ComponentModel.DataAnnotations;

namespace jamesthew.com
{
    public class _recepie
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string RecipeName { get; set; }
        [Required]
        public string RecipeDescription { get; set; }

        [Required]
        public string RecipeType { get; set; }
        [Required]
        public IFormFile Photo { get; set; }

    }
}
