﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace jamesthew.com.Migrations
{
    /// <inheritdoc />
    public partial class add : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_tblrecepie",
                table: "tblrecepie");

            migrationBuilder.RenameTable(
                name: "tblrecepie",
                newName: "uploadrecepie");

            migrationBuilder.AddPrimaryKey(
                name: "PK_uploadrecepie",
                table: "uploadrecepie",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_uploadrecepie",
                table: "uploadrecepie");

            migrationBuilder.RenameTable(
                name: "uploadrecepie",
                newName: "tblrecepie");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tblrecepie",
                table: "tblrecepie",
                column: "Id");
        }
    }
}
