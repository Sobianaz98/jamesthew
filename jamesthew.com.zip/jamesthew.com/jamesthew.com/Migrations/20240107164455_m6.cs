﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace jamesthew.com.Migrations
{
    /// <inheritdoc />
    public partial class m6 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "contest",
                columns: table => new
                {
                    userid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    contest_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    contest_desc = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    contest_prize = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    contest_winner = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_contest", x => x.userid);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "contest");
        }
    }
}
