﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace jamesthew.com.Migrations
{
    /// <inheritdoc />
    public partial class role : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_uploadrecepie",
                table: "uploadrecepie");

            migrationBuilder.RenameTable(
                name: "uploadrecepie",
                newName: "tblrecepie");

            migrationBuilder.AddColumn<int>(
                name: "role",
                table: "tblregister",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_tblrecepie",
                table: "tblrecepie",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_tblrecepie",
                table: "tblrecepie");

            migrationBuilder.DropColumn(
                name: "role",
                table: "tblregister");

            migrationBuilder.RenameTable(
                name: "tblrecepie",
                newName: "uploadrecepie");

            migrationBuilder.AddPrimaryKey(
                name: "PK_uploadrecepie",
                table: "uploadrecepie",
                column: "Id");
        }
    }
}
