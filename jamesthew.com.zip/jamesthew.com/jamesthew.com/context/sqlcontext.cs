﻿using jamesthew.com.Models;
using Microsoft.EntityFrameworkCore;

namespace jamesthew.com.context;

public class Sqlcontext : DbContext
{
    public Sqlcontext(DbContextOptions<Sqlcontext> option) : base(option)
    {

    }
    public DbSet<admintips> tbladmintips { get; set; }
    public DbSet<announcements> announcements { get; set; }

    public DbSet<usermodel> tblregister { get; set; }
    public DbSet<feedback> feedback { get; set; }
    public DbSet<contest> contest { get; set; }
    public DbSet<subscription> subscription { get; set; }
    public DbSet<recepie> tblrecepie { get; set; }
    public DbSet<useruploadrecepie> tbluserrecepie { get; set; }
    public DbSet<useruploadtips> useruploadtips { get; set; }
    public DbSet<usercontest> usercontest { get; set; }




}
