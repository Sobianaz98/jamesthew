﻿function search() {
    alert("abc");
}
